binary2bcd_double_dabble will get 8-bit binary input, then give 8-bit packed BCD outputs(00\~99) and 16-bit unpacked BCD outputs(0000\~0909). 

The testbench should be time-independent, which means that the testing input should be independent of time, it should be an event trigger(in this lab, it's a clock trigger).
